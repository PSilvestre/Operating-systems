#ifndef _SERVER_FUNC_
#define _SERVER_FUNC_

void functionA(int a, char* returnValue);

void functionB(int a, int b, char* returnValue);

void functionC(char* a, char* returnValue);

#endif
