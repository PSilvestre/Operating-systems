#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <pthread.h>

#include "udp_comm.h"
#include "server_functions.h"

#define BUFSIZE 1024

struct requestInformation {
	struct sockaddr_in* clientAddr;
	char* request;
};

struct requestInformation* newRequestInformation() {
	struct requestInformation* req = malloc (sizeof(struct requestInformation));
	req->clientAddr = malloc(sizeof(struct sockaddr_in));
	req->request = malloc(sizeof(char) * BUFSIZE);
	return req;
}

void freeRequestInformation(struct requestInformation* req) {
	free(req->clientAddr);
	free(req->request);
	free(req);
}

		
int server(int port){

	//Main cycle of the server.
	while(1) {
		//Prepara as estruturas em memória para receber um novo pedido.
		struct requestInformation* req = newRequestInformation();

	}
}

int main( int argc, char *argv[]){
	int port;

	if( argc == 2){
		port = atoi(argv[1]);
	} else {
		printf("Usage: %s port\n", argv[0]);
		return 1;
	}

	return server(port);
}

